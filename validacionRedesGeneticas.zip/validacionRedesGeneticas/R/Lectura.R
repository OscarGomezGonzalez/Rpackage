#' @title Dibuja el histograma de una variable superponiendo la densidad normal ajustada
#' @description Función que dibuja el histograma de una variable x, superponiendo la densidad normal
#' ajustada. Si el usuario lo desea puede superponer también un estimador de núcleo de la densidad.
#' @param x vector de datos cuyo histograma se va a calcular
#' @param dens valor lógico: TRUE=Superponer estimador de núcleo de la densidad
#' @return el histograma con la densidad normal superpuesta
#' @export normalHist
#' @examples
#' u=rnorm(1000,100,12)
#' normalHist(u);
#' normalHist(u,dens=TRUE)
#' normalHist(u,dens=TRUE,col="lightcyan")
#'
lecturaRed.prueba = function(nombre,carpetaRedesPrueba){
  aux <- read.delim2(paste0(carpetaRedesPrueba,"/",nombre), sep="")
  return(aux)
}

#' @title Dibuja el histograma de una variable superponiendo la densidad normal ajustada
#' @description Función que dibuja el histograma de una variable x, superponiendo la densidad normal
#' ajustada. Si el usuario lo desea puede superponer también un estimador de núcleo de la densidad.
#' @param x vector de datos cuyo histograma se va a calcular
#' @param dens valor lógico: TRUE=Superponer estimador de núcleo de la densidad
#' @return el histograma con la densidad normal superpuesta
#' @export normalHist
#' @examples
#' u=rnorm(1000,100,12)
#' normalHist(u);
#' normalHist(u,dens=TRUE)
#' normalHist(u,dens=TRUE,col="lightcyan")
#'
lecturaRed.archivo = function(nombreArchivo,carpetaLectura){
  aux <- read.delim2(paste0(carpetaLectura,"/",nombreArchivo), sep="")
  return(aux)
}

#' @title Dibuja el histograma de una variable superponiendo la densidad normal ajustada
#' @description Función que dibuja el histograma de una variable x, superponiendo la densidad normal
#' ajustada. Si el usuario lo desea puede superponer también un estimador de núcleo de la densidad.
#' @param x vector de datos cuyo histograma se va a calcular
#' @param dens valor lógico: TRUE=Superponer estimador de núcleo de la densidad
#' @return el histograma con la densidad normal superpuesta
#' @export normalHist
#' @examples
#' u=rnorm(1000,100,12)
#' normalHist(u);
#' normalHist(u,dens=TRUE)
#' normalHist(u,dens=TRUE,col="lightcyan")
#'
lecturaRed.carpeta = function(carpetaLectura){
  listaArchivos = list.files(path = carpetaLectura ,recursive = FALSE)
  grafoFundido = validacionRedesGeneticas::cargarVariosGrafos.fundirGrafos(listaArchivos,carpetaLectura)
  return(grafoFundido)
}

#' @title Dibuja el histograma de una variable superponiendo la densidad normal ajustada
#' @description Función que dibuja el histograma de una variable x, superponiendo la densidad normal
#' ajustada. Si el usuario lo desea puede superponer también un estimador de núcleo de la densidad.
#' @param x vector de datos cuyo histograma se va a calcular
#' @param dens valor lógico: TRUE=Superponer estimador de núcleo de la densidad
#' @return el histograma con la densidad normal superpuesta
#' @export normalHist
#' @examples
#' u=rnorm(1000,100,12)
#' normalHist(u);
#' normalHist(u,dens=TRUE)
#' normalHist(u,dens=TRUE,col="lightcyan")
#'
cargarVariosGrafos.fundirGrafos = function(listaArchivos,carpetaLectura){
  grafoFundido=validacionRedesGeneticas::lecturaRed.archivo(listaArchivos[1],carpetaLectura)
  if(1<length(listaArchivos)){
    lista=listaArchivos[-1]
    for(i in lista){
      grafoFundido=rbind(grafoFundido,validacionRedesGeneticas::lecturaRed.archivo(i,carpetaLectura))
    }
  }
  return(grafoFundido)
}

